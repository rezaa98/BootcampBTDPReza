<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite login</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>c9a58234-f428-4ff4-a69d-eb4a17a0493e</testSuiteGuid>
   <testCaseLink>
      <guid>b13d3106-f953-4811-8274-6fe38a41ff75</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/pre test day 1/negative case</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>90b5a630-9a67-4a09-8533-6c97354e67dd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/pre test day 1/positive case</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
