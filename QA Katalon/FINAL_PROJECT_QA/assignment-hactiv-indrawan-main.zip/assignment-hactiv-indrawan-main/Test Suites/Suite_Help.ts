<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Help</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>9d728cab-97c4-4c38-bf4b-dcf8f78acea5</testSuiteGuid>
   <testCaseLink>
      <guid>9563ccb2-dc1d-4916-9bae-ad2f1650e787</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_003</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3e32648c-40c7-49b1-990f-f3172776a392</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_004</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
