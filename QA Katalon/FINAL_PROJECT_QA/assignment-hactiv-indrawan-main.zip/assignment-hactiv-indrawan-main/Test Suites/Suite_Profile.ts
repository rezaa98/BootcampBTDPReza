<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Profile</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>88949a16-af17-41ac-8146-3466d50ba24a</testSuiteGuid>
   <testCaseLink>
      <guid>4f0a6519-0cd8-45c4-bd0f-d6a8d84b32b7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>991312a8-211b-4787-94c9-a08e37b61f8a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
