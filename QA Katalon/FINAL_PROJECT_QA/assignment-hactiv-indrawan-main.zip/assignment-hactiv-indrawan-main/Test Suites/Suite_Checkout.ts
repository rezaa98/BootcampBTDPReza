<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Checkout</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>e162b514-7895-4904-b98a-02c678b6bea8</testSuiteGuid>
   <testCaseLink>
      <guid>25670bd2-5c5b-4c3b-ae06-75ac4d2b7a8c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_007</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9166896e-22e2-447d-8871-b6cd237983ac</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_008</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
