<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Category</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>193a8b79-1733-495e-a8de-2be41819e3d6</testSuiteGuid>
   <testCaseLink>
      <guid>cda7f037-6fbd-4c29-aabb-18c7903ba44b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_005</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3fdbe8ff-1fa5-4988-8af1-a7a6444b01f4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ECOM_006</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
