Nama         : Reza Yusuf Maulana
No. Peserta  : JVSB001ONL015
Kode. Peserta: JVSB001ONL015
Link Github : https://github.com/rezaa98/BootcampBTDPReza
Panduan Penggunaan Aplikasi :
1. LuasLingkaran.Java
   Fungsi ini digunakan untuk melakukan penghitungan Luas Lingkaran
   dengan cara menginput nilai jari-jari dan luas lingkaran akan terhitung
   secara otomatis.

2. Aritmatika.Java
    Fungsi aritmatika digunakan untuk melakukan perhitungan aritmatika
    seperti tambah, kurang, kali, bagi serta menampilkan hasilnya

3. IncrementDecrement.Java
    Fungsi ini digunakan untuk mensimulasikan penggunaan Fungsi
    increment dan decrement dan implementasinya terhadap kodingan.
    serta membedakan perbedaan ++i dengan ++i serta --i dan i--

4. Perbandingan TrueFalse.Java
    Fungsi ini digunakan untuk melakukan fungsi logika true or false 
    dengan fungsi pembanding logika.

5. Penjumlahan XY
    fungsi ini digunakan untuk melakukan penghitungan dengan terstruktur
    yang mana mendahulukan fungsi yang terdapat di dalam kurung terlebih dahulu
    lalu ke proses aritmatika selanjutnya

6. Lanjutan Penjumlahan XY
    fungsi ini untuk melanjutkan penghitungan aritmatika dan 
    dilanjutkan dengan operasi logika true or false