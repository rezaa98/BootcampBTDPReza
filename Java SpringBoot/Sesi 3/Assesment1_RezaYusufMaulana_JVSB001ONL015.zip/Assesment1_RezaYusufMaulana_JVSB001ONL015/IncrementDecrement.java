package Assesment1_RezaYusufMaulana_JVSB001ONL015;

public class IncrementDecrement {
    public static void main(String[] args) {
     int a = 0;
     int b= 0;
     int c = 9;
     int d = 9;
     
     //print pertama
     System.out.println("Print ke 1");
     System.out.println("A = "+ a++);
     System.out.println("B = "+ ++b);
     System.out.println("C = "+ c--);
     System.out.println("D = "+ --d);

     //print kedua
     System.out.println("Print ke 2");
     System.out.println("A = "+ a++);
     System.out.println("B = "+ ++b);
     System.out.println("C = "+ c--);
     System.out.println("D = "+ --d);


     //print ketiga
     System.out.println("Print ke 3");
     System.out.println("A = "+ a++);
     System.out.println("B = "+ ++b);
     System.out.println("C = "+ c--);
     System.out.println("D = "+ --d);


     //print keempat
     System.out.println("Print ke 4");
     System.out.println("A = "+ a++);
     System.out.println("B = "+ ++b);
     System.out.println("C = "+ c--);
     System.out.println("D = "+ --d);

    }
}
