package Assesment1_RezaYusufMaulana_JVSB001ONL015;

public class Aritmatika {
    public static void main(String[] args) {
        int a = 12;
        int b = 8;
        int c = 5;

        //hitung
        int hasil1 = a + b - c ;
        int hasil2 = a * b / c ;
        int hasil3 = a + b * c ;
        int hasil4 = a + b / c ;
        int hasil5 = (a + b) * c ;
        int hasil6 = (a - b) * c ;

        //cetak
        System.out.println(hasil1);
        System.out.println(hasil2);
        System.out.println(hasil3);
        System.out.println(hasil4);
        System.out.println(hasil5);
        System.out.println(hasil6);

    }
}
