Nama         : Reza Yusuf Maulana
No. Peserta  : JVSB001ONL015
Kode. Peserta: JVSB001ONL015
Link Github : https://github.com/rezaa98/BootcampBTDPReza
Panduan Penggunaan Aplikasi :
1. Latihan1.Java
   Fungsi ini digunakan untuk mencari nilai tertinggi, lalu nilai terendah 
   serta nilai rata - rata dari 3 angka yang di inputkan

2. Latihan2.Java
   Fungsi ini digunakan untuk melihat posisi tempat duduk dari
   data yang diinputkan pada aplikasi menggunakan array

3. Latihan3.Java
    Fungsi ini untuk menghitung harga jual yang telah di potong
    dengan total diskon serta perhitungannya

4. Latihan4.Java
    Fungsi ini digunakan untuk mencari tahu apakah tahun ini 
    merupakan tahun kabisat atau bukan, dan menampilkan outputnya.

5. Point of Sales
    fungsi ini digunakan untuk melakukan perhitungan kasir sederhana
    dengan model cli, ddengan menginput jumlah barang, kuantitas barang
    serta total harganya.

