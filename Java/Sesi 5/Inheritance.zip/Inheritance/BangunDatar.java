package Inheritance;

public class BangunDatar {
    double luas (){
        System.out.println("=====Menghitung Luas Bangun Datar : =========");
        return 0;
    }
    double keliling(){
        System.out.println("==== Menghitung keliling Bangun Datar : =====");
        return 0;
    }
}
